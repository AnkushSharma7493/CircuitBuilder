'use strict';
var docType = angular.module('componentTypeService', []);
docType.value('ComponentTypes',{
	componentList : [
		
		{
			name : 'Sensor1',
			type : 'Sensor',
			id:'1',
			properties : [],
			namespace :'MicroGrid.OnePhase.Components.Sensor.Sensor',
			subComponent:['SubComponentA','SubComponentB','SubComponentC'],
			icon : 'img\\sensor.png'},
		
		
		
		
		
		
		
		
		
		{name : 'Resistive1',type : 'Resistive',id:'2',properties : [],namespace : 'MicroGrid.OnePhase.Components.Load.Resistive',subComponent:['SubComponentA','SubComponentB','SubComponentC'],icon : 'img\\resistive.png'},
		{name : 'FeederTie1',type : 'FeederTie',id:'3',properties : [],namespace : 'MicroGrid.OnePhase.Components.Switch.FeederTie',subComponent:['SubComponentA','SubComponentB','SubComponentC'],icon : 'img\\newFeeder.png'},
		{name : 'PowerSource1',type : 'PowerSource',id:'4',properties : [{name : 'P_Capacity',value:''},{name : 'P_in',value:''}],namespace : 'MicroGrid.OnePhase.Sources.PowerSource',subComponent:['SubComponentA','SubComponentB','SubComponentC'],icon : 'img\\powersource.png'},
		{name : 'NewFeeder1',type : 'NewFeeder',id:'5',properties : [],namespace : 'MicroGrid.OnePhase.Components.Transmission.NewFeeder',subComponent:['SubComponentA','SubComponentB','SubComponentC'],icon : 'img\\newFeeder.png'},
		{name : 'BooleanPulse1',type : 'BooleanPulse',id:'6',properties : [{name : 'width',value:''}],namespace : 'MicroGrid.OnePhase.Sources.PowerSource',subComponent:['SubComponentA','SubComponentB','SubComponentC']},
		{name : 'const1',type : 'Constant',id:'7',properties : [{name : 'K',value:''}], namespace : 'Modelica.Blocks.Sources.Constant',subComponent:['SubComponentA','SubComponentB','SubComponentC']}
		],
linkList :['v_in_left','v_out_left','v_in_right','v_out_right','N','P','I','y','Right','Left','terminal','V_in','v_in','V_out','v_out','V_in_right','V_in_left','control_R','control_L','feder']

});


