'use strict';

/*
 * Able to open multiple windows simultaniously
 * 
 * --> on remove button on component
 * 		-> remove from gridMatrix
 * 		-> remove from appContext.component
 * 		-> remove any exiting connection
 * 
 * --> on rearrange
 * 		-> update undo array 
 * 
 * call findconnectedCell()
 * remove element from the array in undo function
 * reArrange : remove checkbox, and add alert "select another" location over  the screen.
 * Connection :remove * , add css line
 * Add popup modal to modify component properties
 * Add popupto add new component in the list
 * -> increase row and col by10 on select at index=max-5;
 * -> blink jquery update
 * */


var designerControllers = angular.module('designerControllers', []);

designerControllers
		.controller(
				'designerControllers',
				['$scope','ComponentTypes','designerService',function($scope,ComponentTypes,designerService) {
					
					/**************************************************************/
					//load empty component grid
					/**************************************************************/
					$scope.loadComponent=function()
					{
						$scope.gridMatrix=new Array($scope.ROWS);
						for (let i=0; i <$scope.ROWS; i++)
						{
							$scope.gridMatrix[i]=new Array($scope.COLUMNS);
						}
					}
					
					
					/**************************************************************/
					//App init
					/**************************************************************/
					$scope.init=function()
					{
						// load components object
						$scope.componentList=ComponentTypes.componentList;
							
						//Application context						 
						$scope.appContext={
								undo :[],
								designSchema :{component : [], connection : []}
								};
						
						$scope.connector=[]; //temp array to hold the connection coordinates
						$scope.componentIndex=0;
						$scope.connectionIndex=0;
						
						// set grid dimentsion
						$scope.ROWS=25;
						$scope.COLUMNS=30;	
						
						$scope.loadComponent();
						$scope.selectedComponentName="No Component Selected";
						$scope.connections=
						{
							sourceRow : null,
							sourceColumn : null, 
							destinationRow : null,
							destinationColumn : null
						}
						$scope.mode = "Design";
						$scope.blinkFrequency=100;
						$scope.blinkTimeOut=600;
					}
					
					$scope.init();
					
					/**************************************************************/
					//Component Select 
					/**************************************************************/
					$scope.selectComponent=function(component){
						$scope.mode="Design";
						$scope.selectedComponent=component;
						$scope.selectedComponentName=component.name;
						$("#alertBox").removeClass("panel-red");
						$("#alertBox").addClass("panel-green");
					}

					
					/**************************************************************/
					//cell Select 
					/**************************************************************/
					$scope.cellSelected=function(row,col)
					{
						switch($scope.mode)
						{
						case "Design" : $scope.getDesignMode(row,col);break;
						case "connection" : $scope.getConnectionMode(row,col);break;
						case "rearrange" :$scope.getRearrangeMode(row,col); break;
						case "openCellRearrange" : $scope.getOpenCellRearrangeMode(row,col);break;
						}
					}

					/**************************************************************/
					//Call Design Logic 
					/**************************************************************/
					$scope.getDesignMode=function(row,col)
					{
						if($scope.selectedComponent!=null)
						{
							var componentCoordinate={row : row, col : col};
							$scope.appContext.undo.push({type : "COMPONENT",coordinate : componentCoordinate});
							$scope.selectedComponent.coordinate=componentCoordinate;
							$scope.selectedComponent.id=$scope.componentIndex;
							$scope.componentIndex++;
							$scope.appContext.designSchema.component.push($scope.selectedComponent);
							$scope.gridMatrix[row][col]=$scope.selectedComponent;
							$scope.selectedComponent=null;
							$scope.selectedComponentName="Selected Another Component";
							$("#alertBox").removeClass("panel-green");
							$("#alertBox").addClass("panel-red");
						}
						else
						{
							$scope.selectedComponentName="Please Select Component";
							$scope.blink();
						}
					}

					/**************************************************************/
					//ReArrange components
					/**************************************************************/
					$scope.reArrange=function()
					{
						$scope.mode="rearrange";
					}
					
					/**************************************************************/
					//Call Rearrange prior Logic 
					/**************************************************************/
					$scope.getRearrangeMode=function(row,col)
					{
						if(typeof $scope.gridMatrix[row][col]=="undefined")
						{
							$scope.mode = "Design"
						}
						else
						{
						$scope.connections.sourceRow = row;
						$scope.connections.sourceColumn = col;
						$scope.selectedComponentName="Click at another Location";
						$scope.blink();
						$scope.mode ="openCellRearrange"
						}
					}
					
					/**************************************************************/
					//Call Rearrange after Logic 
					/**************************************************************/
					$scope.getOpenCellRearrangeMode=function(row,col)
					{
						$scope.gridMatrix[row][col]=$scope.gridMatrix[$scope.connections.sourceRow][$scope.connections.sourceColumn];
						//$scope.selectedComponent=$scope.gridMatrix[row][col];
						//$scope.getDesignMode(row,col);
						$scope.mode = "Design";
						
						//delete existing connection
						var id=$scope.gridMatrix[$scope.connections.sourceRow][$scope.connections.sourceColumn].id;
						for(let i=0;i<$scope.appContext.designSchema.connection.length;i++)
						{
							if($scope.appContext.designSchema.connection[i].srcid==id )
							{
								$scope.removeList($scope.appContext.designSchema.connection[i].ConnectionCells);
								$scope.remove($scope.connections.sourceRow,$scope.connections.sourceColumn);
								
								$scope.connections.sourceRow=row;
								$scope.connections.sourceColumn=col;
								
								var destID=$scope.appContext.designSchema.connection[i].destid;
								
								for(let i=0;i<$scope.appContext.designSchema.component.length;i++)
								{
									if($scope.appContext.designSchema.component[i].id==destID )
									{
										
										getConnectionMode($scope.appContext.designSchema.component[i].coordinate.row,$scope.appContext.designSchema.component[i].coordinate.col);
										break;
									}
								}
								break;
							}
							else if($scope.appContext.designSchema.connection[i].destid==id)
							{
								$scope.removeList($scope.appContext.designSchema.connection[i].ConnectionCells);
								$scope.remove($scope.connections.sourceRow,$scope.connections.sourceColumn);
								
								var srcID=$scope.appContext.designSchema.connection[i].srcid;
								
								for(let i=0;i<$scope.appContext.designSchema.component.length;i++)
								{
									if($scope.appContext.designSchema.component[i].id==srcID)
									{
										$scope.connections.sourceRow=$scope.appContext.designSchema.component[i].coordinate.row;
										$scope.connections.sourceColumn=$scope.appContext.designSchema.component[i].coordinate.col;
										getConnectionMode(row,col);
										break;
									}
								}
								break;
							}
						}	
					}

					/**************************************************************/
					//Connect components
					/**************************************************************/
					$scope.connectComponent=function()
					{
					//Set mode to Connection
						$scope.mode="connection";
					}
					
					/**************************************************************/
					//Call Connection logic
					/**************************************************************/
					$scope.getConnectionMode=function(row,col){
						if(typeof $scope.gridMatrix[row][col]=="undefined")
						{
							$scope.mode = "Design"
						}
						else
						{
							//---------------------------------------------------> verify if checkbox is ticked
							if($scope.connections.sourceRow==null && $scope.connections.sourceColumn==null)
							{
								$scope.connections.sourceRow=row;
								$scope.connections.sourceColumn=col;
							}
							else
							{
								$scope.connections.destinationRow=row;
								$scope.connections.destinationColumn=col;
								
								//calculate the set of cell need to mark dotted
								$scope.findconnectedCell($scope.connections.sourceRow,$scope.connections.sourceColumn,
														$scope.connections.destinationRow,$scope.connections.destinationColumn);
								/*
								 * Reset mode to design 
								 * */
								$scope.reset();
							}
						}
					}
					
					/**************************************************************/
					//Add connection to context 
					/**************************************************************/
					$scope.addConnectionToContext=function(sourceRow,sourceColumn,destinationRow,destinationColumn,connectionList)
					{
						$scope.appContext.designSchema.connection.push({
							id 		: $scope.connectionIndex,
							srcid 	: $scope.gridMatrix[sourceRow][sourceColumn].id,
							destid 	: $scope.gridMatrix[destinationRow][destinationColumn].id,
							ConnectionCells : connectionList
						});
						$scope.connectionIndex++;
					}
					
					/**************************************************************/
					//Calculate cell to connect two components 
					/**************************************************************/
					$scope.findconnectedCell=function(sRow,sCol,dRow,dCol)
					{
						switch ($scope.getRelativeDirection(sRow,sCol,dRow,dCol)) 
						{
					    case "LEFTUP":    		$scope.LeftUp(sRow,sCol,dRow,dCol);  break;
					    case "LEFTDOWN":   		$scope.LeftDown(sRow,sCol,dRow,dCol);  break;
					    case "RIGHTUP":    		$scope.RightUp(sRow,sCol,dRow,dCol);  break;
					    case "RIGHTDOWN":   	$scope.RightDown(sRow,sCol,dRow,dCol);  break;
					    case "UP":   			$scope.Up(sRow,sCol,dRow,dCol);  break;
					    case "DOWN":   		 	$scope.Down(sRow,sCol,dRow,dCol);  break;
					    case "LEFT":   	 		$scope.Left(sRow,sCol,dRow,dCol);  break;
					    case "RIGHT":    		$scope.Right(sRow,sCol,dRow,dCol);  break;
						}
						
						console.log($scope.connector);
						$scope.appContext.undo.push({type : "CONNECTOR",coordinate : $scope.connector});
						$scope.addConnectionToContext(sRow,sCol,dRow,dCol,$scope.connector);
						$scope.connector=[];
					}
					
					
					/**************************************************************/
					// Same Row connection logic 
					/**************************************************************/
					$scope.Left=function(sRow,sCol,dRow,dCol)
					{
						while(sCol<dCol-1)
						{
							// checking if cell have coponent
							if($scope.isComponentCell(sRow,++sCol))
							{	
								if(sRow>0){
									sRow=sRow-1;	
									$scope.LeftUp(sRow,sCol,dRow,dCol);
								}
								else
								{
									sRow=sRow+1;
									leftDown(sRow,sCol,dRow,dCol);
								}
								break;
								
							}
							else{
								$scope.gridMatrix[sRow][sCol]={};
								$scope.gridMatrix[sRow][sCol].connectedCell=true;	
							}
						}
					}

					/**************************************************************/
					//Component at Left Up position - 2nd quadant
					/**************************************************************/
					$scope.LeftUp=function(sRow,sCol,dRow,dCol)
					{
						var DownRightDirection=false;
						var RightDownDirection=false;
						
						//check the DownRight path
						var destRow=$scope.checkDownDirection(sRow,sCol,dRow,dCol);
						if(destRow!=-1)
						{
							var col=$scope.checkRightDirection(destRow,sCol,dRow,dCol-1);
							if(col!=-1)
							{
								DownRightDirection=true;
							}
						}
						
						//check the RightDown path
						var destCol=$scope.checkRightDirection(sRow,sCol,dRow,dCol);
						if(destCol!=-1)
						{
							var row=$scope.checkDownDirection(sRow,destCol,dRow-1,dCol);
							if(row!=-1)
							{
								RightDownDirection=true;
							}
						}
						
						// Decide which path to choose
						if(RightDownDirection && DownRightDirection || (!RightDownDirection && !DownRightDirection))
						{
							$scope.moveRightDown(sRow,sCol,dRow,dCol);
						}
						else if(RightDownDirection)
						{
							$scope.moveRightDown(sRow,sCol,dRow,dCol);
						}
						else if(DownRightDirection)
						{
							$scope.moveDownRight(sRow,sCol,dRow,dCol);
						}
					}
				
					/**************************************************************/
					//Component at Left Up position 
					/**************************************************************/
					$scope.LeftDown=function(sRow,sCol,dRow,dCol)
					{
						var UpRightDirection=false;
						var RightUpDirection=false;
						
						//check the DownRight path
						var destRow=$scope.checkUpDirection(sRow,sCol,dRow,dCol);
						if(destRow!=-1)
						{
							var col=$scope.checkRightDirection(destRow,sCol,dRow,dCol-1);
							if(col!=-1)
							{
								UpRightDirection=true;
							}
						}
						
						//check the RightDown path
						var destCol=$scope.checkRightDirection(sRow,sCol,dRow,dCol);
						if(destCol!=-1)
						{
							var row=$scope.checkUpDirection(sRow,destCol,dRow-1,dCol);
							if(row!=-1)
							{
								RightUpDirection=true;
							}
						}
						
						// Decide which path to choose
						if(RightUpDirection && UpRightDirection || (!RightUpDirection && !UpRightDirection))
						{
							$scope.moveUpRight(sRow,sCol,dRow,dCol);
						}
						else if(RightUpDirection)
						{
							$scope.moveRightUp(sRow,sCol,dRow,dCol);
						}
						else if(UpRightDirection)
						{
							$scope.moveUpRight(sRow,sCol,dRow,dCol);
						}
					}
				
					/**************************************************************/
					//Component at Left Up position 
					/**************************************************************/
					$scope.RightUp=function(sRow,sCol,dRow,dCol)
					{
						
					}
					
					/**************************************************************/
					//Component at Left Up position 
					/**************************************************************/
					$scope.RightDown=function(sRow,sCol,dRow,dCol)
					{
						
					}
					
					/**************************************************************/
					//Move  RightDown  -- 1st Quandant
					/**************************************************************/
					$scope.moveRightDown=function(sRow,sCol,dRow,dCol)
					{
						var obsticleCol;
						var obsticleRow;
						
						//move right
						if((obsticleCol=$scope.moveRight(sRow,sCol,dRow,dCol))==9999)
						{
							if((obsticleRow=$scope.moveDown(sRow,dCol,dRow-1,dCol))!=9999)
							{
								//check if the obsticleRow is same as sRow, 
								if(obsticleRow==sRow)
								{
									//Un connect the (obsticleRow,sCol)	
									$scope.gridMatrix[obsticleRow][dCol]=null;
								}
									
								$scope.markConnectionCell(obsticleRow,--dCol);
								$scope.LeftUp(obsticleRow,dCol,dRow,dCol);
							}
						}
						else
						{
							$scope.markConnectionCell(++sRow,obsticleCol);
							//obsticle at right path
							if($scope.getRelativeDirection(sRow,obsticleCol,dRow,dCol)=="LEFTUP")
							{
								$scope.LeftUp(sRow,obsticleCol,dRow,dCol);
							}
							else if($scope.getRelativeDirection(sRow,obsticleCol,dRow,dCol)=="LEFT")
							{
								$scope.Left(sRow,obsticleCol,dRow,dCol);
							}
							else
							{
								console.log("******************************************************************");
								console.log("Exception occured at moveRightDown functionwhile handling obsticle");
								console.log("******************************************************************");
							}
						}						
					}
				
					/**************************************************************/
					//Move  DownRight - 1 quadant
					/**************************************************************/
					$scope.moveDownRight=function(sRow,sCol,dRow,dCol)
					{
						var obsticleRow;
						var obsticleCol;
						
						//move Down
						if((obsticleRow=$scope.moveDown(sRow,sCol,dRow,dCol))==9999)
						{	
							if((obsticleCol=$scope.moveRight(dRow,sCol,dRow,dCol-1))!=9999)
							{
								//check if the obsticleCol is same as sCol 
								if(obsticleCol==sCol)
								{
									//Un connect the (obsticleRow,sCol)	
									$scope.gridMatrix[dRow][obsticleCol]=null;
								}
								//obsticle at down path
								$scope.markConnectionCell(--dRow,obsticleCol);
								$scope.LeftUp(dRow,obsticleCol,dRow,dCol);
							}
						}
						else
						{
							//mark the new column as connect b4 callong recursion
							$scope.markConnectionCell(obsticleRow,++sCol);
							//obsticle at right path
							if($scope.getRelativeDirection(obsticleRow,sCol,dRow,dCol)=="LEFTUP")
							{
								$scope.LeftUp(obsticleRow,sCol,dRow,dCol);
							}
							else if($scope.getRelativeDirection(obsticleRow,sCol,dRow,dCol)=="DOWN")
							{
								$scope.Down(sRow,++obsticleCol,dRow,dCol);
							}
							else
							{
								console.log("******************************************************************");
								console.log("Exception occured at moveDownRight functionwhile handling obsticle");
								console.log("******************************************************************");
							}
						}						
					}


					/**************************************************************/
					//Move  UpRight - 3rd Quadant :called from LeftDown
					/**************************************************************/
					$scope.moveUpRight=function(sRow,sCol,dRow,dCol)
					{
						var obsticleRow;
						var obsticleCol;
						
						//move Up
						if((obsticleRow=$scope.moveUp(sRow,sCol,dRow,dCol))==9999)
						{	
							if((obsticleCol=$scope.moveRight(dRow,sCol,dRow,dCol-1))!=9999)
							{
								//check if the obsticleCol is same as sCol 
								if(obsticleCol==sCol)
								{
									//Unconnect the (obsticleRow,sCol)	
									$scope.gridMatrix[dRow][obsticleCol]=null;
								}
								//obsticle at down path
								$scope.markConnectionCell(++dRow,obsticleCol);
								$scope.LeftDown(dRow,obsticleCol,dRow,dCol);
							}
						}
						else
						{
							//mark the new column as connect b4 callong recursion
							$scope.markConnectionCell(obsticleRow,++sCol);
							//obsticle at right path
							if($scope.getRelativeDirection(obsticleRow,sCol,dRow,dCol)=="LEFTDOWN")
							{
								$scope.LeftDown(obsticleRow,sCol,dRow,dCol);
							}
							else if($scope.getRelativeDirection(obsticleRow,sCol,dRow,dCol)=="DOWN")
							{
								$scope.Up(sRow,++obsticleCol,dRow,dCol);
							}
							else
							{
								console.log("******************************************************************");
								console.log("Exception occured at moveUpRight functionwhile handling obsticle");
								console.log("******************************************************************");
							}
						}	
					}

					/**************************************************************/
					//Move  RightUp  - 3rd Quadant called from LeftDown
					/**************************************************************/
					$scope.moveRightUp=function(sRow,sCol,dRow,dCol)
					{
						var obsticleCol;
						var obsticleRow;
						
						//move right
						if((obsticleCol=$scope.moveRight(sRow,sCol,dRow,dCol))==9999)
						{
							if((obsticleRow=$scope.moveUp(sRow,dCol,dRow-1,dCol))!=9999)
							{
								//check if the obsticleRow is same as sRow, 
								if(obsticleRow==sRow)
								{
									$scope.gridMatrix[obsticleRow][dCol]=null;
								}
									
								$scope.markConnectionCell(obsticleRow,--dCol);
								$scope.LeftDown(obsticleRow,dCol,dRow,dCol);
							}
						}
						else
						{
							$scope.markConnectionCell(--sRow,obsticleCol);
							//obsticle at right path
							if($scope.getRelativeDirection(sRow,obsticleCol,dRow,dCol)=="LEFTDOWN")
							{
								$scope.LeftUp(sRow,obsticleCol,dRow,dCol);
							}
							else if($scope.getRelativeDirection(sRow,obsticleCol,dRow,dCol)=="LEFT")
							{
								$scope.Left(sRow,obsticleCol,dRow,dCol);
							}
							else
							{
								console.log("******************************************************************");
								console.log("Exception occured at moveRightUp functionwhile handling obsticle");
								console.log("******************************************************************");
							}
						}	
					}
					
					/**************************************************************/
					//Move  LeftDown - 2nd Quadant
					/**************************************************************/
					$scope.movLeftDown=function(sRow,sCol,dRow,dCol)
					{
						var obsticleCol;
						var obsticleRow;
						
						//move Left
						if((obsticleCol=$scope.moveLeft(sRow,sCol,dRow,dCol))==9999)
						{
							if((obsticleRow=$scope.moveDown(sRow,dCol,dRow-1,dCol))!=9999)
							{
								//check if the obsticleRow is same as sRow, 
								if(obsticleRow==sRow)
								{
									//Un connect the (obsticleRow,sCol)	
									$scope.gridMatrix[obsticleRow][dCol]=null;
								}
									
								$scope.markConnectionCell(obsticleRow,dCol+1);
								$scope.RightUp(obsticleRow,dCol-1,dRow,dCol);
							}
						}
						else
						{
							$scope.markConnectionCell(++sRow,obsticleCol);
							//obsticle at right path
							if($scope.getRelativeDirection(sRow,obsticleCol,dRow,dCol)=="LEFTUP")
							{
								$scope.LeftUp(sRow,obsticleCol,dRow,dCol);
							}
							else if($scope.getRelativeDirection(sRow,obsticleCol,dRow,dCol)=="LEFT")
							{
								$scope.Left(sRow,obsticleCol,dRow,dCol);
							}
							else
							{
								console.log("******************************************************************");
								console.log("Exception occured at moveRightDown functionwhile handling obsticle");
								console.log("******************************************************************");
							}
						}
					}
					
					/**************************************************************/
					//Move  DownLeft - 2nd Quadant
					/**************************************************************/
					$scope.moveDownLeft=function(sRow,sCol,dRow,dCol)
					{
						
					}
					
					/**************************************************************/
					//Move  LeftUp - 2nd Quadant
					/**************************************************************/
					$scope.moveLeftUp=function(sRow,sCol,dRow,dCol)
					{
						
					}
					
					/**************************************************************/
					//Move  UpLeft - 2nd Quadant
					/**************************************************************/
					$scope.moveUpLeft=function(sRow,sCol,dRow,dCol)
					{
						
					}
					
					/**************************************************************/
					//Move to the right direction
					/**************************************************************/
					$scope.moveRight=function(sRow,sCol,dRow,dCol)
					{
						while(sCol<dCol)
						{
							if($scope.isComponentCell(sRow,++sCol))
							{
								return --sCol;
							}
							else
							{
								$scope.markConnectionCell(sRow,sCol,dRow,dCol);
							}
						}
						return 9999;
					}
					
					/**************************************************************/
					//Move to the left direction
					/**************************************************************/
					$scope.moveLeft=function(sRow,sCol,dRow,dCol)
					{
						while(sCol<dCol)
						{
							if($scope.isComponentCell(sRow,--sCol))
							{
								return --sCol;
							}
							else
							{
								$scope.markConnectionCell(sRow,sCol,dRow,dCol);
							}
						}
						return 9999;
					}
					/**************************************************************/
					//Move to the right direction
					/**************************************************************/
					$scope.moveUp=function(sRow,sCol,dRow,dCol)
					{
						while(sCol<dCol)
						{
							if($scope.isComponentCell(--sRow,sCol))
							{
								return --sRow;
							}
							else
							{
								$scope.markConnectionCell(sRow,sCol,dRow,dCol);
							}
						}
						return 9999;
					}
					/**************************************************************/
					//Move to the right direction
					/**************************************************************/
					$scope.moveDown=function(sRow,sCol,dRow,dCol)
					{
						while(sRow<dRow)
						{
							if($scope.isComponentCell(++sRow,sCol))
							{
								return --sRow;
							}
							else
							{
								$scope.markConnectionCell(sRow,sCol,dRow,dCol);
							}
						}
						return 9999;
					}
					
					
					/**************************************************************/
					//Mark the cell as connected
					/**************************************************************/
					$scope.markConnectionCell=function(Row,Col)
					{
						$scope.gridMatrix[Row][Col]={};
						$scope.gridMatrix[Row][Col].connectedCell=true;
						$scope.connector.push({row :Row, col :Col});
						
					}
					
					
					/**************************************************************/
					//Check the right side path : exclude source coordinate and include dest coordinate
					/**************************************************************/
					$scope.checkRightDirection=function(sRow,sCol,dRow,dCol)
					{
						while(sCol<dCol)
						{
							if($scope.isComponentCell(sRow,++sCol))
							{
								return -1;
							}
							
						}
						return sCol;
					}
				
					/**************************************************************/
					//Check the left side path :  exclude source coordinate and include dest coordinate
					/**************************************************************/
					$scope.checkLeftDirection=function(sRow,sCol,dRow,dCol)
					{
						while(sCol>=dCol)
						{
							if($scope.isComponentCell(sRow,sCol--))
							{
								return -1;
							}
							
						}
						return sCol;
					}


					/**************************************************************/
					//Check the UP side path :  exclude source coordinate and include dest coordinate
					/**************************************************************/
					$scope.checkUpDirection=function(sRow,sCol,dRow,dCol)
					{
						while(sRow>=dRow)
						{
							if($scope.isComponentCell(sRow--,sCol))
							{
								return -1;
							}
							
						}
						return sRow;
					}
					
					/**************************************************************/
					//Check the Down side path :  exclude source coordinate and include dest coordinate
					/**************************************************************/
					$scope.checkDownDirection=function(sRow,sCol,dRow,dCol)
					{
						while(sRow<dRow)
						{
							if($scope.isComponentCell(++sRow,sCol))
							{
								return -1;
							}
							
						}
						return sRow;
					}
					
					
					/**************************************************************/
					//verify the cell having any component 
					/**************************************************************/
					$scope.isComponentCell=function(sRow,sCol)
					{
						if(typeof $scope.gridMatrix[sRow][sCol]!="undefined" && $scope.gridMatrix[sRow][sCol]!=null && $scope.gridMatrix[sRow][sCol].name)
						{
							return true;
						}
						else
						{
							return false;
						}
					}
					/**************************************************************/
					//Left to Down Connection logic 
					/**************************************************************/
					$scope.LeftDown=function(sRow,sCol,dRow,dCol)
					{
						
					}
					
					

					/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++/
					/+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++/
					/+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++/
					//											Utility functions 
					/+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++/
					/+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++/
					/++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/

					
					/**************************************************************/
					//Download Xml Schema 
					/**************************************************************/
					$scope.downloadXML=function(xmlSchemaObj)
					{
						
					    var element       = document.getElementById('designDownloader');
					    element.href      = 'data:' + "text/json;charset=utf-8," + encodeURIComponent(JSON.stringify($scope.schemaGeneration($scope.appContext.designSchema)));
					    element.download  = 'CircuitDesign.xml';
					}
					
					
					/**************************************************************/
					//Generate Design Schema 
					/**************************************************************/
					$scope.schemaGeneration=function(payload) 
					{
						var header='<?xml version="1.0"?> <microgrid version="0.1">	<model id="MicroGrid_Layout_1_phase">';
						var footer='</model></microgrid>';
						var body="";
						var components="";
						var connections="";
						var equationStartTag='<equation>';
						var equationEndTag='</equation>';
						var componentEndTag='</component>';
						
							//adding components to xml 
						   for(let i=0;i<payload.component.length;i++)
							{
							   components+='<component id="'+payload.component[i].id+'" name="'+payload.component[i].name+'" type="'+payload.component[i].type+'">'+componentEndTag;
							}
						   
						   //adding connection to xml
						   for(let i=0;i<payload.connection.length;i++)
						   {
							   connections+='<connection destid="'+payload.connection[i].destid+'" destlink="'+payload.connection[i].destlink+'" id="'+payload.connection[i].id+'" srcid="'+payload.connection[i].srcid+'" srclink="'+payload.connection[i].srclink+'" />';
						   }
						   
						   body=header+components+equationStartTag+connections+equationEndTag+footer;
						  
						return body;
					}
					
					/**************************************************************/
					//Reset state
					/**************************************************************/
					$scope.reset=function()
					{
						$scope.connections.sourceRow=null;
						$scope.connections.sourceColumn=null;
						$scope.connections.destinationRow=null;
						$scope.connections.destinationColumn=null;
						$scope.mode="Design";
					}
					
					/**************************************************************/
					//Call Alert Box Blink Logic 
					/**************************************************************/
					$scope.blink=function()
					{
						var index=1;
							var blinkTimer = setInterval(function(){
									if(index%2==0)
									{
										$("#alertBox").removeClass("panel-red");
										$("#alertBox").addClass("panel-green");
										index++;
									}
									else
									{
										$("#alertBox").removeClass("panel-green");
										$("#alertBox").addClass("panel-red");
										index++;
									}
								
							}, $scope.blinkFrequency);
							setTimeout(function(){  clearInterval(blinkTimer);}, $scope.blinkTimeOut);
					}
					

					/**************************************************************/
					//remove component 
					/**************************************************************/
					$scope.removeList=function(arr)
					{
						for(let j=0;j<arr.length;j++)
						{
							$scope.remove(arr[j].row,arr[j].col);
						}
					}
					
					/**************************************************************/
					//remove component 
					/**************************************************************/
					$scope.remove=function(row,col)
					{
						$scope.gridMatrix[row][col]=null;
					}
					
					/**************************************************************/
					//Clear grid 
					/**************************************************************/
					$scope.clear=function()
					{
						$scope.gridMatrix=null;
						$scope.loadComponent();
						//clear app context;
						$scope.appContext.undo=[];
						$scope.appContext.designSchema.component=[];
						$scope.appContext.designSchema.connection=[];
						$scope.selectedComponenName="No Component Selected";
						$scope.reset();
					}
					
					/**************************************************************/
					//Undo grid
					/**************************************************************/
					$scope.undoActivity=function()
					{
						var element=$scope.appContext.undo.pop();
						if(element.type=="COMPONENT")
						{
							$scope.remove(element.coordinate.row,element.coordinate.col);
							$scope.appContext.designSchema.component.pop();
							
						}
						else if(element.type=="CONNECTOR")
						{
							for(let i=0;i<element.coordinate.length;i++)
							{
								$scope.remove(element.coordinate[i].row,element.coordinate[i].col);
							}
							$scope.appContext.designSchema.connection.pop();
						}
					}
					
					/**************************************************************/
					//Calculate relative direction 
					/**************************************************************/
					$scope.getRelativeDirection=function(sRow,sCol,dRow,dCol)
					{
						//calculate directions
						if(sCol<dCol && sRow<dRow)
						{
							// source is left and up	
							return "LEFTUP";
						}
						else if(sCol<dCol && sRow>dRow)
						{
							//source is left and down
							return "LEFTDOWN";
						}
						else if(sCol>dCol && sRow>dRow)
						{
							// source is right and down
							return "RIGHTDOWN";
						}
						else if(sCol>dCol && sRow<dRow)
						{
							// source is right and up
							return "RIGHTUP";
						}
						else if(sCol<dCol && sRow==dRow)
						{
							// source is left and on same row
							return "LEFT";
						}
						else if(sCol>dCol && sRow==dRow)
						{
							// source is right and on same row
							return "RIGHT";
						}
						else if(sCol==dCol && sRow>dRow)
						{
							// source is down and on same column
							return "DOWN";
						}
						else if(sCol==dCol && sRow<dRow)
						{
							// source is up and on same column
							return "UP";
						}
					}
					
					
				} ]);