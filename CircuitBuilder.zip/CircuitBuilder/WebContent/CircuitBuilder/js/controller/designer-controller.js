'use strict';
// GIT BRANCH : CLIENTVERSION

var designerControllers = angular.module('designerControllers', []);

designerControllers
		.controller(
				'designerControllers',
				['$scope','ComponentTypes','designerService','$http',function($scope,ComponentTypes,designerService,$http) {
					
					/**************************************************************/
					//App init
					/**************************************************************/
					$scope.init=function()
					{
						// load components object
						$scope.componentList=ComponentTypes.componentList;
						$scope.showGrid=true;
							
						//Application context						 
						$scope.appContext={
								undo :[],
								designSchema :{component : [], connection : []}
								};
						
						$scope.connector=[]; //temp array to hold the connection coordinates
						$scope.componentIndex=1;
						$scope.connectionIndex=1;
						
						// set grid dimentsion
						$scope.ROWS=25;
						$scope.COLUMNS=30;	
						
						$scope.loadComponent();
						$scope.selectedComponentName="No Component Selected";
						$scope.connections=
						{
							sourceRow : null,
							sourceColumn : null, 
							destinationRow : null,
							destinationColumn : null
						}
						$scope.mode = "Design";
						$scope.blinkFrequency=100;
						$scope.blinkTimeOut=600;

						$scope.rightDir="RIGHT";
						$scope.leftDir="LEFT";
						$scope.downDir="DOWN";
						$scope.upDir="UP";
						$scope.tiggleDesignXMLButton="XML";
						$scope.sureToClear=false;
					}
					
					/**************************************************************/
					//load empty component grid
					/**************************************************************/
					$scope.loadComponent=function()
					{
						$scope.gridMatrix=new Array($scope.ROWS);
						for (let i=0; i <$scope.ROWS; i++)
						{
							$scope.gridMatrix[i]=new Array($scope.COLUMNS);
						}
					}
					
					/**************************************************************/
					//load Rows
					/**************************************************************/
					$scope.loadRows=function(count)
					{
						for (let i=0; i <count; i++)
						{
							$scope.gridMatrix[$scope.ROWS+i]=new Array($scope.COLUMNS);
						}
					}
					
					/**************************************************************/
					//load Columns
					/**************************************************************/
					$scope.loadCol=function(count)
					{
						for (let i=0; i <$scope.ROWS; i++)
						{
							for (let j=0; j <count; j++)
							{
							$scope.gridMatrix[i].push(null);
							}
						}
					}
					
					$scope.init();
					
					/**************************************************************/
					//Component Select 
					/**************************************************************/
					$scope.selectComponent=function(component){
						$scope.mode="Design";
						$scope.selectedComponent=component;
						$scope.selectedComponentName=component.name;
						$("#alertBox").removeClass("panel-red");
						$("#alertBox").addClass("panel-green");
						$("#wrapper").addClass("grabbing");
					}

					
					/**************************************************************/
					//cell Select 
					/**************************************************************/
					$scope.cellSelected=function(row,col)
					{
						//check coulumn and row selected 
						if(row>$scope.ROWS-5)
						{
							$scope.loadRows(20);
							$scope.ROWS+=20;

						} 
						if(col>$scope.COLUMNS-5)
						{
							$scope.loadCol(20);
							$scope.COLUMNS+=20;
						}
						
						console.log("--------------->"+$scope.cancelComp);
						
						//$scope.cancelComponent($parent.$index,$index)
						
						switch($scope.mode)
						{
						case "Design" : $scope.getDesignMode(row,col);break;
						case "connection" : $scope.getConnectionMode(row,col);break;
						case "rearrange" :$scope.getRearrangeMode(row,col); break;
						case "openCellRearrange" : $scope.getOpenCellRearrangeMode(row,col);break;
						}
					}

					/**************************************************************/
					//Call Design Logic 
					/**************************************************************/
					$scope.getDesignMode=function(row,col)
					{
						if($scope.selectedComponent!=null)
						{
							$("#wrapper").removeClass("grabbing");
							var componentCoordinate={row : row, col : col};
							$scope.appContext.undo.push({type : "COMPONENT",coordinate : componentCoordinate});
							
							var component=
							{
									coordinate : componentCoordinate,
									name : $scope.selectedComponent.name,
									id : $scope.componentIndex,
									property1 : $scope.selectedComponent.property1
							}
							
							
							$scope.componentIndex++;
							$scope.appContext.designSchema.component.push(component);
							
							$scope.gridMatrix[row][col]=component;
							$scope.selectedComponent=null;
							$scope.selectedComponentName="Selected Another Component";
							$("#alertBox").removeClass("panel-green");
							$("#alertBox").addClass("panel-red");
						}
						else
						{
							$scope.selectedComponentName="Please Select Component";
							$scope.blink();
						}
					}

					/**************************************************************/
					//ReArrange components
					/**************************************************************/
					$scope.reArrange=function()
					{
						$scope.mode="rearrange";
					}
					
					/**************************************************************/
					//Call Rearrange prior Logic 
					/**************************************************************/
					$scope.getRearrangeMode=function(row,col)
					{
						if(typeof $scope.gridMatrix[row][col]=="undefined")
						{
							$scope.mode = "Design"
						}
						else
						{
						$scope.connections.sourceRow = row;
						$scope.connections.sourceColumn = col;
						$scope.selectedComponentName="Click at another Location";
						$scope.blink();
						$scope.mode ="openCellRearrange"
						}
					}
					
					/**************************************************************/
					//Call Rearrange after Logic 
					/**************************************************************/
					$scope.getOpenCellRearrangeMode=function(row,col)
					{
						$scope.gridMatrix[row][col]=$scope.gridMatrix[$scope.connections.sourceRow][$scope.connections.sourceColumn];
						//$scope.selectedComponent=$scope.gridMatrix[row][col];
						//$scope.getDesignMode(row,col);
						$scope.mode = "Design";
						
						//delete existing connection
						var id=$scope.gridMatrix[$scope.connections.sourceRow][$scope.connections.sourceColumn].id;
						for(let i=0;i<$scope.appContext.designSchema.connection.length;i++)
						{
							if($scope.appContext.designSchema.connection[i].srcid==id )
							{
								$scope.removeList($scope.appContext.designSchema.connection[i].ConnectionCells);
								$scope.remove($scope.connections.sourceRow,$scope.connections.sourceColumn);
								
								$scope.connections.sourceRow=row;
								$scope.connections.sourceColumn=col;
								
								var destID=$scope.appContext.designSchema.connection[i].destid;
								
								for(let i=0;i<$scope.appContext.designSchema.component.length;i++)
								{
									if($scope.appContext.designSchema.component[i].id==destID )
									{
										
										getConnectionMode($scope.appContext.designSchema.component[i].coordinate.row,$scope.appContext.designSchema.component[i].coordinate.col);
										break;
									}
								}
								break;
							}
							else if($scope.appContext.designSchema.connection[i].destid==id)
							{
								$scope.removeList($scope.appContext.designSchema.connection[i].ConnectionCells);
								$scope.remove($scope.connections.sourceRow,$scope.connections.sourceColumn);
								
								var srcID=$scope.appContext.designSchema.connection[i].srcid;
								
								for(let i=0;i<$scope.appContext.designSchema.component.length;i++)
								{
									if($scope.appContext.designSchema.component[i].id==srcID)
									{
										$scope.connections.sourceRow=$scope.appContext.designSchema.component[i].coordinate.row;
										$scope.connections.sourceColumn=$scope.appContext.designSchema.component[i].coordinate.col;
										getConnectionMode(row,col);
										break;
									}
								}
								break;
							}
						}	
					}

					/**************************************************************/
					//Connect components
					/**************************************************************/
					$scope.connectComponent=function()
					{
					//Set mode to Connection
						$scope.mode="connection";
					}
					
					/**************************************************************/
					//Call Connection logic
					/**************************************************************/
					$scope.getConnectionMode=function(row,col){
						if(typeof $scope.gridMatrix[row][col]=="undefined")
						{
							$scope.mode = "Design"
						}
						else
						{
							//---------------------------------------------------> verify if checkbox is ticked
							if($scope.connections.sourceRow==null && $scope.connections.sourceColumn==null)
							{
								$scope.connections.sourceRow=row;
								$scope.connections.sourceColumn=col;
							}
							else
							{
								$scope.connections.destinationRow=row;
								$scope.connections.destinationColumn=col;
								
								//calculate the set of cell need to mark dotted
								$scope.findconnectedCell($scope.connections.sourceRow,$scope.connections.sourceColumn,
														$scope.connections.destinationRow,$scope.connections.destinationColumn);
								/*
								 * Reset mode to design 
								 * */
								$scope.reset();
							}
						}
					}
					
					/**************************************************************/
					//Add connection to context 
					/**************************************************************/
					$scope.addConnectionToContext=function(sourceRow,sourceColumn,destinationRow,destinationColumn,connectionList)
					{
						$scope.appContext.designSchema.connection.push({
							id 		: $scope.connectionIndex,
							srcid 	: $scope.gridMatrix[sourceRow][sourceColumn].id,
							destid 	: $scope.gridMatrix[destinationRow][destinationColumn].id,
							ConnectionCells : connectionList
						});
						$scope.connectionIndex++;
					}
					
					/**************************************************************/
					//Calculate cell to connect two components 
					/**************************************************************/
					$scope.findconnectedCell=function(sRow,sCol,dRow,dCol)
					{
						switch ($scope.getRelativeDirection(sRow,sCol,dRow,dCol)) 
						{
					    case "LEFTUP":    		$scope.LeftUp(sRow,sCol,dRow,dCol);  break;
					    case "LEFTDOWN":   		$scope.LeftDown(sRow,sCol,dRow,dCol);  break;
					    case "RIGHTUP":    		$scope.RightUp(sRow,sCol,dRow,dCol);  break;
					    case "RIGHTDOWN":   	$scope.RightDown(sRow,sCol,dRow,dCol);  break;
					    case "UP":   			$scope.Up(sRow,sCol,dRow,dCol);  break;
					    case "DOWN":   		 	$scope.Down(sRow,sCol,dRow,dCol);  break;
					    case "LEFT":   	 		$scope.Left(sRow,sCol,dRow,dCol);  break;
					    case "RIGHT":    		$scope.Right(sRow,sCol,dRow,dCol);  break;
						}
						
						console.log($scope.connector);
						$scope.appContext.undo.push({type : "CONNECTOR",coordinate : $scope.connector});
						$scope.addConnectionToContext(sRow,sCol,dRow,dCol,$scope.connector);
						$scope.connector=[];
					}
					
					
					/**************************************************************/
					// Same Row connection logic 
					/**************************************************************/
					$scope.Left=function(sRow,sCol,dRow,dCol)
					{
						var obsticleCol;
						if((obsticleCol=$scope.moveRight(sRow,sCol,dRow,dCol-1))!=9999)
						{
							if(sRow+1<$scope.ROWS)
							{
								$scope.markConnectionCell(sRow,obsticleCol,$scope.downDir);
								$scope.markConnectionCell(++sRow,obsticleCol,$scope.rightDir);
								$scope.LeftDown(sRow,obsticleCol,dRow,dCol);
							}
							else
							{
								$scope.markConnectionCell(sRow,obsticleCol,$scope.upDir);
								$scope.markConnectionCell(--sRow,obsticleCol,$scope.rightDir);
								$scope.LeftUp(sRow,obsticleCol,dRow,dCol);
							}
						}
					}
					
					
					/**************************************************************/
					// Same Row connection logic 
					/**************************************************************/
					$scope.Right=function(sRow,sCol,dRow,dCol)
					{
						var obsticleCol;
						if((obsticleCol=$scope.moveLeft(sRow,sCol,dRow,dCol+1))!=9999)
						{
							if(sRow+1<$scope.ROWS)
							{
								$scope.markConnectionCell(sRow,obsticleCol,$scope.downDir);
								$scope.markConnectionCell(++sRow,obsticleCol,$scope.leftDir);
								$scope.RightDown(sRow,obsticleCol,dRow,dCol);
							}
							else
							{
								$scope.markConnectionCell(sRow,obsticleCol,$scope.upDir);
								$scope.markConnectionCell(--sRow,obsticleCol,$scope.leftDir);
								$scope.RightUp(sRow,obsticleCol,dRow,dCol);
							}
						}
					}
					
					
					/**************************************************************/
					// Same Row connection logic 
					/**************************************************************/
					$scope.Up=function(sRow,sCol,dRow,dCol)
					{
						var obsticleRow;
						if((obsticleRow=$scope.moveDown(sRow,sCol,dRow-1,dCol))!=9999)
						{
							if(sCol+1<$scope.COLUMNS)
							{
								$scope.markConnectionCell(obsticleRow,sCol+1);
								$scope.RightUp(obsticleRow,sCol+1,dRow,dCol);
							}
							else
							{
								$scope.markConnectionCell(obsticleRow,sCol-1);
								$scope.LeftUp(obsticleRow,sCol-1,dRow,dCol);
							}
						}
					}
					
					
					/**************************************************************/
					// Same Row connection logic 
					/**************************************************************/
					$scope.Down=function(sRow,sCol,dRow,dCol)
					{
						
						var obsticleRow;
						if((obsticleRow=$scope.moveUp(sRow,sCol,dRow-1,dCol))!=9999)
						{
							if(sCol+1<$scope.COLUMNS)
							{
								$scope.markConnectionCell(obsticleRow,sCol+1);
								$scope.RightDown(obsticleRow,sCol+1,dRow,dCol);
							}
							else
							{
								$scope.markConnectionCell(obsticleRow,sCol-1);
								$scope.LeftDown(obsticleRow,sCol-1,dRow,dCol);
							}
						}
					}

					/**************************************************************/
					//Component at Left Up position - 2nd quadant
					/**************************************************************/
					$scope.LeftUp=function(sRow,sCol,dRow,dCol)
					{
						var DownRightDirection=false;
						var RightDownDirection=false;
						
						//check the DownRight path
						var destRow=$scope.checkDownDirection(sRow,sCol,dRow,dCol);
						if(destRow!=-1)
						{
							var col=$scope.checkRightDirection(destRow,sCol,dRow,dCol-1);
							if(col!=-1)
							{
								DownRightDirection=true;
							}
						}
						
						//check the RightDown path
						var destCol=$scope.checkRightDirection(sRow,sCol,dRow,dCol);
						if(destCol!=-1)
						{
							var row=$scope.checkDownDirection(sRow,destCol,dRow-1,dCol);
							if(row!=-1)
							{
								RightDownDirection=true;
							}
						}
						
						// Decide which path to choose
						if(RightDownDirection && DownRightDirection || (!RightDownDirection && !DownRightDirection))
						{
							$scope.moveRightDown(sRow,sCol,dRow,dCol);
						}
						else if(RightDownDirection)
						{
							$scope.moveRightDown(sRow,sCol,dRow,dCol);
						}
						else if(DownRightDirection)
						{
							$scope.moveDownRight(sRow,sCol,dRow,dCol);
						}
					}
				
					/**************************************************************/
					//Component at Left Down position 
					/**************************************************************/
					$scope.LeftDown=function(sRow,sCol,dRow,dCol)
					{
						var UpRightDirection=false;
						var RightUpDirection=false;
						
						//check the DownRight path
						var destRow=$scope.checkUpDirection(sRow,sCol,dRow,dCol);
						if(destRow!=-1)
						{
							var col=$scope.checkRightDirection(destRow,sCol,dRow,dCol-1);
							if(col!=-1)
							{
								UpRightDirection=true;
							}
						}
						
						//check the RightDown path
						var destCol=$scope.checkRightDirection(sRow,sCol,dRow,dCol);
						if(destCol!=-1)
						{
							var row=$scope.checkUpDirection(sRow,destCol,dRow+1,dCol);
							if(row!=-1)
							{
								RightUpDirection=true;
							}
						}
						
						// Decide which path to choose
						if(RightUpDirection && UpRightDirection || (!RightUpDirection && !UpRightDirection))
						{
							$scope.moveUpRight(sRow,sCol,dRow,dCol);
						}
						else if(RightUpDirection)
						{
							$scope.moveRightUp(sRow,sCol,dRow,dCol);
						}
						else if(UpRightDirection)
						{
							$scope.moveUpRight(sRow,sCol,dRow,dCol);
						}
					}
				
					/**************************************************************/
					//Component at Right Up position 
					/**************************************************************/
					$scope.RightUp=function(sRow,sCol,dRow,dCol)
					{
						var DownLeftDirection=false;
						var LeftDownDirection=false;
						
						//check the DownLeft path
						var destRow=$scope.checkDownDirection(sRow,sCol,dRow,dCol);
						if(destRow!=-1)
						{
							var col=$scope.checkLeftDirection(destRow,sCol,dRow,dCol+1);
							if(col!=-1)
							{
								DownLeftDirection=true;
							}
						}
						
						//check the RightDown path
						var destCol=$scope.checkLeftDirection(sRow,sCol,dRow,dCol);
						if(destCol!=-1)
						{
							var row=$scope.checkDownDirection(sRow,destCol,dRow-1,dCol);
							if(row!=-1)
							{
								LeftDownDirection=true;
							}
						}
						
						// Decide which path to choose
						if(LeftDownDirection && DownLeftDirection || (!LeftDownDirection && !DownLeftDirection))
						{
							$scope.moveLeftDown(sRow,sCol,dRow,dCol);
						}
						else if(LeftDownDirection)
						{
							$scope.moveLeftDown(sRow,sCol,dRow,dCol);
						}
						else if(DownLeftDirection)
						{
							$scope.moveDownLeft(sRow,sCol,dRow,dCol);
						}
					}
					
					/**************************************************************/
					//Component at Right Down position 
					/**************************************************************/
					$scope.RightDown=function(sRow,sCol,dRow,dCol)
					{
						var LeftUpDirection=false;
						var UpLeftDirection=false;
						
						//check the UpLeft path
						var destRow=$scope.checkUpDirection(sRow,sCol,dRow,dCol);
						if(destRow!=-1)
						{
							var col=$scope.checkLeftDirection(destRow,sCol,dRow,dCol+1);
							if(col!=-1)
							{
								UpLeftDirection=true;
							}
						}
						
						//check the RightDown path
						var destCol=$scope.checkLeftDirection(sRow,sCol,dRow,dCol);
						if(destCol!=-1)
						{
							var row=$scope.checkUpDirection(sRow,destCol,dRow+1,dCol);
							if(row!=-1)
							{
								LeftUpDirection=true;
							}
						}
						
						// Decide which path to choose
						if(LeftUpDirection && UpLeftDirection || (!LeftUpDirection && !UpLeftDirection))
						{
							$scope.moveLeftUp(sRow,sCol,dRow,dCol);
						}
						else if(LeftUpDirection)
						{
							$scope.moveLeftUp(sRow,sCol,dRow,dCol);
						}
						else if(UpLeftDirection)
						{
							$scope.moveUpLeft(sRow,sCol,dRow,dCol);
						}
					}
					
					/**************************************************************/
					//Move  RightDown
					/**************************************************************/
					$scope.moveRightDown=function(sRow,sCol,dRow,dCol)
					{
						var obsticleCol;
						var obsticleRow;
						
						//move right
						if((obsticleCol=$scope.moveRight(sRow,sCol,dRow,dCol))==9999)
						{
							if((obsticleRow=$scope.moveDown(sRow,dCol,dRow-1,dCol))!=9999)
							{
								//check if the obsticleRow is same as sRow, 
								if(obsticleRow==sRow)
								{
									//Un connect the (obsticleRow,sCol)	
									$scope.gridMatrix[obsticleRow][dCol]=null;
								}
									
								$scope.markConnectionCell(obsticleRow,dCol-1);
								$scope.LeftUp(obsticleRow,dCol-1,dRow,dCol);
							}
						}
						else
						{
							$scope.markConnectionCell(++sRow,obsticleCol);
							//obsticle at right path
							if($scope.getRelativeDirection(sRow,obsticleCol,dRow,dCol)=="LEFTUP")
							{
								$scope.LeftUp(sRow,obsticleCol,dRow,dCol);
							}
							else if($scope.getRelativeDirection(sRow,obsticleCol,dRow,dCol)=="LEFT")
							{
								$scope.Left(sRow,obsticleCol,dRow,dCol);
							}
							else
							{
								console.log("******************************************************************");
								console.log("Exception occured at moveRightDown functionwhile handling obsticle");
								console.log("******************************************************************");
							}
						}						
					}
				
					/**************************************************************/
					//Move  DownRight
					/**************************************************************/
					$scope.moveDownRight=function(sRow,sCol,dRow,dCol)
					{
						var obsticleRow;
						var obsticleCol;
						
						//move Down
						if((obsticleRow=$scope.moveDown(sRow,sCol,dRow,dCol))==9999)
						{	
							if((obsticleCol=$scope.moveRight(dRow,sCol,dRow,dCol-1))!=9999)
							{
								//check if the obsticleCol is same as sCol 
								if(obsticleCol==sCol)
								{
									//Un connect the (obsticleRow,sCol)	
									$scope.gridMatrix[dRow][obsticleCol]=null;
								}
								//obsticle at down path
								$scope.markConnectionCell(dRow-1,obsticleCol);
								$scope.LeftUp(dRow-1,obsticleCol,dRow,dCol);
							}
						}
						else
						{
							//mark the new column as connect b4 callong recursion
							$scope.markConnectionCell(obsticleRow,++sCol);
							//obsticle at right path
							if($scope.getRelativeDirection(obsticleRow,sCol,dRow,dCol)=="LEFTUP")
							{
								$scope.LeftUp(obsticleRow,sCol,dRow,dCol);
							}
							else if($scope.getRelativeDirection(obsticleRow,sCol,dRow,dCol)=="DOWN")
							{
								$scope.Left(sRow,++obsticleCol,dRow,dCol);
							}
							else
							{
								console.log("******************************************************************");
								console.log("Exception occured at moveDownRight functionwhile handling obsticle");
								console.log("******************************************************************");
							}
						}						
					}

					/**************************************************************/
					//Move  UpRight - 3rd Quadant :called from LeftDown
					/**************************************************************/
					$scope.moveUpRight=function(sRow,sCol,dRow,dCol)
					{
						var obsticleRow;
						var obsticleCol;
						
						//move Up
						if((obsticleRow=$scope.moveUp(sRow,sCol,dRow,dCol))==9999)
						{	
							if((obsticleCol=$scope.moveRight(dRow,sCol,dRow,dCol-1))!=9999)
							{
								//check if the obsticleCol is same as sCol 
								if(obsticleCol==sCol)
								{
									//Unconnect the (obsticleRow,sCol)	
									$scope.gridMatrix[dRow][obsticleCol]=null;
								}
								//obsticle at down path
								$scope.markConnectionCell(dRow+1,obsticleCol);
								$scope.LeftDown(dRow+1,obsticleCol,dRow,dCol);
							}
						}
						else
						{
							//mark the new column as connect b4 callong recursion
							$scope.markConnectionCell(obsticleRow,++sCol);
							//obsticle at right path
							if($scope.getRelativeDirection(obsticleRow,sCol,dRow,dCol)=="LEFTDOWN")
							{
								$scope.LeftDown(obsticleRow,sCol,dRow,dCol);
							}
							else if($scope.getRelativeDirection(obsticleRow,sCol,dRow,dCol)=="DOWN")
							{
								$scope.Up(sRow,++obsticleCol,dRow,dCol);
							}
							else
							{
								console.log("******************************************************************");
								console.log("Exception occured at moveUpRight functionwhile handling obsticle");
								console.log("******************************************************************");
							}
						}	
					}

					/**************************************************************/
					//Move  RightUp  - 3rd Quadant called from LeftDown
					/**************************************************************/
					$scope.moveRightUp=function(sRow,sCol,dRow,dCol)
					{
						var obsticleCol;
						var obsticleRow;
						
						//move right
						if((obsticleCol=$scope.moveRight(sRow,sCol,dRow,dCol))==9999)
						{
							if((obsticleRow=$scope.moveUp(sRow,dCol,dRow+1,dCol))!=9999)
							{
								//check if the obsticleRow is same as sRow, 
								if(obsticleRow==sRow)
								{
									$scope.gridMatrix[obsticleRow][dCol]=null;
								}
									
								$scope.markConnectionCell(obsticleRow,dCol+1);
								$scope.LeftDown(obsticleRow,dCol+1,dRow,dCol);
							}
						}
						else
						{
							$scope.markConnectionCell(--sRow,obsticleCol);
							//obsticle at right path
							if($scope.getRelativeDirection(sRow,obsticleCol,dRow,dCol)=="LEFTDOWN")
							{
								$scope.LeftUp(sRow,obsticleCol,dRow,dCol);
							}
							else if($scope.getRelativeDirection(sRow,obsticleCol,dRow,dCol)=="LEFT")
							{
								$scope.Left(sRow,obsticleCol,dRow,dCol);
							}
							else
							{
								console.log("******************************************************************");
								console.log("Exception occured at moveRightUp functionwhile handling obsticle");
								console.log("******************************************************************");
							}
						}	
					}
					
					/**************************************************************/
					//Move  LeftDown - 2nd Quadant
					/**************************************************************/
					$scope.moveLeftDown=function(sRow,sCol,dRow,dCol)  
					{
						var obsticleCol;
						var obsticleRow;
						
						//move Left
						if((obsticleCol=$scope.moveLeft(sRow,sCol,dRow,dCol))==9999)
						{
							if((obsticleRow=$scope.moveDown(sRow,dCol,dRow-1,dCol))!=9999)
							{
								//check if the obsticleRow is same as sRow, 
								if(obsticleRow==sRow)
								{
									$scope.gridMatrix[obsticleRow][dCol]=null;
								}
									
								$scope.markConnectionCell(obsticleRow,dCol+1);
								$scope.RightUp(obsticleRow,dCol+1,dRow,dCol);
							}
						}
						else
						{
							$scope.markConnectionCell(++sRow,obsticleCol);
							//obsticle at right path
							if($scope.getRelativeDirection(sRow,obsticleCol,dRow,dCol)=="RIGHTUP")
							{
								$scope.LeftUp(sRow,obsticleCol,dRow,dCol);
							}
							else if($scope.getRelativeDirection(sRow,obsticleCol,dRow,dCol)=="LEFT")
							{
								$scope.Left(sRow,obsticleCol,dRow,dCol);
							}
							else
							{
								console.log("******************************************************************");
								console.log("Exception occured at moveRightDown functionwhile handling obsticle");
								console.log("******************************************************************");
							}
						}
					}
					
					/**************************************************************/
					//Move  DownLeft - 2nd Quadant
					/**************************************************************/
					$scope.moveDownLeft=function(sRow,sCol,dRow,dCol)
					{
						var obsticleCol;
						var obsticleRow;
						
						//move Left
						if((obsticleRow=$scope.moveDown(sRow,sCol,dRow,dCol))==9999)
						{
							if((obsticleCol=$scope.moveLeft(sRow,dCol,dRow,dCol+1))!=9999)
							{
								//check if the obsticleRow is same as sRow, 
								if(obsticleCol==sCol)
								{
									$scope.gridMatrix[dRow][obsticleCol]=null;
								}
									
								$scope.markConnectionCell(dRow-1,obsticleCol);
								$scope.RightUP(dRow-1,obsticleCol,dRow,dCol);
							}
						}
						else
						{
							$scope.markConnectionCell(obsticleRow,--sCol);
							//obsticle at right path
							if($scope.getRelativeDirection(obsticleRow,sCol,dRow,dCol)=="RIGHTUP")
							{
								$scope.RightUp(sRow,obsticleCol,dRow,dCol);
							}
							else if($scope.getRelativeDirection(sRow,obsticleCol,dRow,dCol)=="UP")
							{
								$scope.Up(sRow,obsticleCol,dRow,dCol);
							}
							else
							{
								console.log("******************************************************************");
								console.log("Exception occured at moveRightDown functionwhile handling obsticle");
								console.log("******************************************************************");
							}
						}
					}
					
					/**************************************************************/
					//Move  LeftUp - 2nd Quadant
					/**************************************************************/
					$scope.moveLeftUp=function(sRow,sCol,dRow,dCol)
					{
						var obsticleCol;
						var obsticleRow;
						
						//move Left
						if((obsticleCol=$scope.moveLeft(sRow,sCol,dRow,dCol))==9999)
						{
							if((obsticleRow=$scope.moveUp(sRow,dCol,dRow+1,dCol))!=9999)
							{
								//check if the obsticleRow is same as sRow, 
								if(obsticleRow==sRow)
								{
									$scope.gridMatrix[obsticleRow][dCol]=null;
								}
									
								$scope.markConnectionCell(obsticleRow,dCol-1);
								$scope.RightDown(obsticleRow,dCol+1,dRow,dCol);
							}
						}
						else
						{
							$scope.markConnectionCell(--sRow,obsticleCol);
							//obsticle at right path
							if($scope.getRelativeDirection(sRow,obsticleCol,dRow,dCol)=="RIGHTDOWN")
							{
								$scope.LeftUp(sRow,obsticleCol,dRow,dCol);
							}
							else if($scope.getRelativeDirection(sRow,obsticleCol,dRow,dCol)=="RIGHT")
							{
								$scope.Left(sRow,obsticleCol,dRow,dCol);
							}
							else
							{
								console.log("******************************************************************");
								console.log("Exception occured at moveRightDown functionwhile handling obsticle");
								console.log("******************************************************************");
							}
						}
					}
					
					/**************************************************************/
					//Move  UpLeft - 2nd Quadant
					/**************************************************************/
					$scope.moveUpLeft=function(sRow,sCol,dRow,dCol)
					{
						var obsticleCol;
						var obsticleRow;
						
						//move Left
						if((obsticleRow=$scope.moveUp(sRow,sCol,dRow,dCol))==9999)
						{
							if((obsticleCol=$scope.moveLeft(sRow,dCol,dRow+1,dCol))!=9999)
							{
								if(obsticleCol==sCol)
								{
									$scope.gridMatrix[sRow][obsticleCol]=null;
								}
								$scope.markConnectionCell(sRow+1,obsticleCol);
								$scope.RightDown(sRow+1,obsticleCol,dRow,dCol);
							}
						}
						else
						{
							$scope.markConnectionCell(obsticleRow,--sCol);
							//obsticle at right path
							if($scope.getRelativeDirection(obsticleRow,sCol,dRow,dCol)=="RIGHTDOWN")
							{
								$scope.LeftUp(obsticleRow,sCol,dRow,dCol);
							}
							else if($scope.getRelativeDirection(obsticleRow,sCol,dRow,dCol)=="DOWN")
							{
								$scope.Left(obsticleRow,sCol,dRow,dCol);
							}
							else
							{
								console.log("******************************************************************");
								console.log("Exception occured at moveRightDown functionwhile handling obsticle");
								console.log("******************************************************************");
							}
						}
					}
					
					/**************************************************************/
					//Move to the right direction
					/**************************************************************/
					$scope.moveRight=function(sRow,sCol,dRow,dCol)
					{
						while(sCol<dCol)
						{
							if($scope.isComponentCell(sRow,++sCol))
							{
								return --sCol;
							}
							else
							{
								$scope.markConnectionCell(sRow,sCol,$scope.rightDir);
							}
						}
						return 9999;
					}
					
					/**************************************************************/
					//Move to the left direction
					/**************************************************************/
					$scope.moveLeft=function(sRow,sCol,dRow,dCol)
					{
						while(sCol>dCol)
						{
							if($scope.isComponentCell(sRow,--sCol))
							{
								return ++sCol;
							}
							else
							{
								$scope.markConnectionCell(sRow,sCol,$scope.leftDir);
							}
						}
						return 9999;
					}
					/**************************************************************/
					//Move to the right direction
					/**************************************************************/
					$scope.moveUp=function(sRow,sCol,dRow,dCol)
					{
						while(sRow>dRow)
						{
							if($scope.isComponentCell(--sRow,sCol))
							{
								return ++sRow;
							}
							else
							{
								$scope.markConnectionCell(sRow,sCol,$scope.upDir);
							}
						}
						return 9999;
					}
					/**************************************************************/
					//Move to the right direction
					/**************************************************************/
					$scope.moveDown=function(sRow,sCol,dRow,dCol)
					{
						while(sRow<dRow)
						{
							if($scope.isComponentCell(++sRow,sCol))
							{
								return --sRow;
							}
							else
							{
								$scope.markConnectionCell(sRow,sCol,$scope.downDir);
							}
						}
						return 9999;
					}
					
					
					/**************************************************************/
					//Check the right side path : exclude source coordinate and include dest coordinate
					/**************************************************************/
					$scope.checkRightDirection=function(sRow,sCol,dRow,dCol)
					{
						while(sCol<dCol)
						{
							if($scope.isComponentCell(sRow,++sCol))
							{
								return -1;
							}
							
						}
						return sCol;
					}
				
					/**************************************************************/
					//Check the left side path :  exclude source coordinate and include dest coordinate
					/**************************************************************/
					$scope.checkLeftDirection=function(sRow,sCol,dRow,dCol)
					{
						while(sCol>dCol)
						{
							if($scope.isComponentCell(sRow,--sCol))
							{
								return -1;
							}
							
						}
						return sCol;
					}


					/**************************************************************/
					//Check the UP side path :  exclude source coordinate and include dest coordinate
					/**************************************************************/
					$scope.checkUpDirection=function(sRow,sCol,dRow,dCol)
					{
						while(sRow>dRow)
						{
							if($scope.isComponentCell(--sRow,sCol))
							{
								return -1;
							}
							
						}
						return sRow;
					}
					
					/**************************************************************/
					//Check the Down side path :  exclude source coordinate and include dest coordinate
					/**************************************************************/
					$scope.checkDownDirection=function(sRow,sCol,dRow,dCol)
					{
						while(sRow<dRow)
						{
							if($scope.isComponentCell(++sRow,sCol))
							{
								return -1;
							}
							
						}
						return sRow;
					}
					
					
					/**************************************************************/
					//verify the cell having any component 
					/**************************************************************/
					$scope.isComponentCell=function(sRow,sCol)
					{
						if(typeof $scope.gridMatrix[sRow][sCol]!="undefined" && $scope.gridMatrix[sRow][sCol]!=null && $scope.gridMatrix[sRow][sCol].name)
						{
							return true;
						}
						else
						{
							return false;
						}
					}
					
					

					/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++/
					/+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++/
					/+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++/
					//											Utility functions 
					/+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++/
					/+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++/
					/++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/

					/**************************************************************/
					//Mark the cell as connected
					/**************************************************************/
					$scope.markConnectionCell=function(Row,Col,direction)
					{
						$scope.gridMatrix[Row][Col]={};
						$scope.gridMatrix[Row][Col].direction=direction;
						$scope.gridMatrix[Row][Col].connectedCell=true;
						$scope.connector.push({row :Row, col :Col});
						
					}
					
					/**************************************************************/
					//Download Xml Schema 
					/**************************************************************/
					$scope.downloadXML=function(xmlSchemaObj)
					{
						$scope.saveJSON($scope.schemaGeneration($scope.appContext.designSchema),'CircuitDesign.xml');
					}
					
					
					
					/**************************************************************/
					//Reset state
					/**************************************************************/
					$scope.reset=function()
					{
						$scope.connections.sourceRow=null;
						$scope.connections.sourceColumn=null;
						$scope.connections.destinationRow=null;
						$scope.connections.destinationColumn=null;
						$scope.componentIndex=1;
						$scope.mode="Design";
					}
					
					/**************************************************************/
					//Call Alert Box Blink Logic 
					/**************************************************************/
					$scope.blink=function()
					{
						var index=1;
							var blinkTimer = setInterval(function(){
									if(index%2==0)
									{
										$("#alertBox").removeClass("panel-red");
										$("#alertBox").addClass("panel-green");
										index++;
									}
									else
									{
										$("#alertBox").removeClass("panel-green");
										$("#alertBox").addClass("panel-red");
										index++;
									}
								
							}, $scope.blinkFrequency);
							setTimeout(function(){  clearInterval(blinkTimer);}, $scope.blinkTimeOut);
					}
					
					/**************************************************************/
					//remove component 
					/**************************************************************/
					$scope.remove=function(row,col)
					{
						$scope.gridMatrix[row][col]=null;
					}

					/**************************************************************/
					//remove component List
					/**************************************************************/
					$scope.removeList=function(arr)
					{
						for(let j=0;j<arr.length;j++)
						{
							$scope.remove(arr[j].row,arr[j].col);
						}
					}
					
					/**************************************************************/
					//Cancel component 
					/**************************************************************/
					$scope.cancelComponent=function(row,col)
					{
						$scope.removeComponentFromContext(row,col);
						$scope.removeConnectionFromContext(row,col);
						$scope.remove(row,col);
					}
					
					/**************************************************************/
					//remove component from context 
					/**************************************************************/
					$scope.removeComponentFromContext=function(row,col)
					{
						//-----------------------> remove element from this index in array
						//$scope.appContext.designSchema.component[$scope.gridMatrix[row][col].id]={};
					}
					
					/**************************************************************/
					//search Component in context 
					/**************************************************************/
					$scope.removeConnectionFromContext=function(row,col)
					{
						var id=$scope.gridMatrix[row][col].id;
						for(let i=0;i<$scope.appContext.designSchema.connection.length;i++)
						{
							if($scope.appContext.designSchema.connection[i].srcid==id || $scope.appContext.designSchema.connection[i].destid==id)
							{
								$scope.removeList($scope.appContext.designSchema.connection[i].ConnectionCells);
								break;
							}
						}
					}
					
					
					/**************************************************************/
					//Clear grid 
					/**************************************************************/
					$scope.clear=function()
					{
						/*if($scope.sureToClear==true)
						{*/
							$scope.gridMatrix=null;
							$scope.loadComponent();
							//clear app context;
							$scope.appContext.undo=[];
							$scope.appContext.designSchema.component=[];
							$scope.appContext.designSchema.connection=[];
							$scope.selectedComponenName="No Component Selected";
							$scope.reset();
						//}
					}
					
					/**************************************************************/
					//Undo grid
					/**************************************************************/
					$scope.undoActivity=function()
					{
						var element=$scope.appContext.undo.pop();
						if(element.type=="COMPONENT")
						{
							$scope.componentIndex--;
							$scope.remove(element.coordinate.row,element.coordinate.col);
							$scope.appContext.designSchema.component.pop();
							
						}
						else if(element.type=="CONNECTOR")
						{
							$scope.connectionIndex--;
							for(let i=0;i<element.coordinate.length;i++)
							{
								$scope.remove(element.coordinate[i].row,element.coordinate[i].col);
							}
							$scope.appContext.designSchema.connection.pop();
						}
					}
					
					/**************************************************************/
					//Calculate relative direction 
					/**************************************************************/
					$scope.getRelativeDirection=function(sRow,sCol,dRow,dCol)
					{
						//calculate directions
						if(sCol<dCol && sRow<dRow)
						{
							// source is left and up	
							return "LEFTUP";
						}
						else if(sCol<dCol && sRow>dRow)
						{
							//source is left and down
							return "LEFTDOWN";
						}
						else if(sCol>dCol && sRow>dRow)
						{
							// source is right and down
							return "RIGHTDOWN";
						}
						else if(sCol>dCol && sRow<dRow)
						{
							// source is right and up
							return "RIGHTUP";
						}
						else if(sCol<dCol && sRow==dRow)
						{
							// source is left and on same row
							return "LEFT";
						}
						else if(sCol>dCol && sRow==dRow)
						{
							// source is right and on same row
							return "RIGHT";
						}
						else if(sCol==dCol && sRow>dRow)
						{
							// source is down and on same column
							return "DOWN";
						}
						else if(sCol==dCol && sRow<dRow)
						{
							// source is up and on same column
							return "UP";
						}
					}
					
					/**************************************************************/
					//Generate Design Schema 
					/**************************************************************/
					$scope.schemaGeneration=function(payload) 
					{
						
					}
					
					/**************************************************************/
					//Generate Design View 
					/**************************************************************/
					$scope.showDesignXML=function()
					{
						$scope.showGrid=!$scope.showGrid;
						if($scope.showGrid==false)
						{
							$scope.tiggleDesignXMLButton="Design";
						}
						else
						{
							$scope.tiggleDesignXMLButton="XML";
						}
					}
					
					/**************************************************************/
					//Save a file as a json 
					/**************************************************************/
					$scope.saveJSON = function(data,filename) {
						    var jsonse = JSON.stringify(data);
						    var blob = new Blob([jsonse], {
						      type: "application/json"
						    });
						   
						    $scope.filename = filename || "CircuitBuilderJson";
						    saveAs(blob, $scope.filename);
						  }
					
					 $scope.method = 'GET';
				     $scope.url = 'cards.json';

					 $scope.load = function() {
				            $scope.code = null;
				            $scope.response = null;
				            $scope.url="appConfigFile.json";

				            $http({method: $scope.method, url: $scope.url}).
				                then(function(response) {
				                    $scope.data = response.data;
				                    console.log("Read file", $scope.url, "successfully.");
				                    console.log("Data ", $scope.data);
				                }, function(response) {
				                    $scope.data = response.data || "Request failed";
				                    console.log("Error reading", $scope.url, ".");
				                });
				        };
					
				} ]);