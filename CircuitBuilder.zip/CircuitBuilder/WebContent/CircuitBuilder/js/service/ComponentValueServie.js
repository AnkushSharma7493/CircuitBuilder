'use strict';
var docType = angular.module('componentTypeService', []);
docType.value('ComponentTypes',{
	componentList : [
		{name : 'component one',id:'1',property1: 'propC1',property2 :'propC11'},
		{name : 'component two',id:'2',property1: 'propC2',property2 :'propC22'},
		{name : 'component three',id:'3',property1: 'propC3',property2 :'propC33'},
		{name : 'component Four',id:'4',property1: 'propC1',property2 :'propC11'},
		{name : 'component Five',id:'5',property1: 'propC2',property2 :'propC22'},
		{name : 'component Six',id:'6',property1: 'propC3',property2 :'propC33'},
		{name : 'component Seven',id:'7',property1: 'propC1',property2 :'propC11'},
		{name : 'component Eight',id:'8',property1: 'propC2',property2 :'propC22'},
		{name : 'component Nine',id:'9',property1: 'propC3',property2 :'propC33'}
	]
});